# ServiceNow collection dependency

Add `servicenow.itsm` to the client repository. Do not replace either requirements file with a copy from another working tree. Keep every existing Windows patching collection entry.

The roles were syntax-checked and linted with `servicenow.itsm` 2.6.3. Use that exact version for the first integration test. The module arguments these roles send are the same from 2.6.3 through 2.16.0, but a floating minimum can install a newer build that has not been run against this client. Pin `2.6.3` until that test passes.

The collection has no extra Ansible collection dependencies and no extra Python packages beyond the AAP 2.7 supported execution environment.

## Files to edit by hand

### `requirements.yml`

This file is for local lint and development. Production jobs take collections from the execution environment.

Inside the existing `collections:` list, add this entry. Leave `ansible.windows` and `community.general` as they already are:

```yaml
  - name: servicenow.itsm
    version: "2.6.3"
```

If the client file already contains `servicenow.itsm`, do not add a second entry. Set that existing entry to `2.6.3` for this test only when the client is not already pinned to a newer certified build they have agreed to keep.

### `execution-environments/windows-patch-ee/requirements.yml`

Add the same entry to this file so the next EE build matches the project file:

```yaml
  - name: servicenow.itsm
    version: "2.6.3"
```

Do not change `ansible.windows`, `community.general`, `execution-environment.yml`, `requirements.txt`, or `bindep.txt` for this transfer. Those files do not need a ServiceNow change.

Adding the pin does not change an image that is already published.

## Project install versus an EE rebuild

A workstation can install the collection for syntax-check and local playbook runs:

```bash
ansible-galaxy collection install servicenow.itsm:==2.6.3
```

That install is enough to discover the roles and syntax-check the test playbooks. It does not put the collection into AAP.

This repository does not deliver collections from a project `collections/` directory. `ansible.cfg` does not set `collections_path`, and job templates use the execution environment on the job. A project copy of `servicenow.itsm` will not make an AAP job succeed when the selected EE lacks the collection.

An EE rebuild is required when the test job template uses `windows-patch-ee` and that published image does not already contain `servicenow.itsm` 2.6.3. Rebuild from `execution-environments/windows-patch-ee` after the requirements pin is merged, then select the new image on the test job template.

An EE rebuild is not required for the first read test when another existing execution environment already contains `servicenow.itsm` 2.6.3. Point only the standalone ServiceNow job template at that image. Leave the Windows patching job template on its current image.

`playbooks/windows/full_patch.yml` does not call these roles. Patching jobs do not need the new collection until someone later integrates the roles into that playbook.
