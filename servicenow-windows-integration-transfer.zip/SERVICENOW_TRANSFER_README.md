# ServiceNow transfer package

Extract this ZIP in the root of the client Windows patching repository. The paths inside the archive are already relative to that root.

```bash
unzip -l servicenow-windows-integration-transfer.zip
unzip servicenow-windows-integration-transfer.zip
```

On Windows, extract with a tool that keeps the directories. Do not extract into a new nested folder and then copy pieces by hand unless the resulting paths match the list below.

## 1. Files included

- `roles/servicenow_patching_change/` including `defaults/main.yml`, `tasks/`, and `README.md`
- `roles/servicenow_incident/` including `defaults/main.yml`, `tasks/`, and `README.md`
- `playbooks/tests/test_snow_change.yml`
- `playbooks/tests/snow_role_test.yml`
- `playbooks/tests/snow_incident_test.yml`
- `playbooks/tests/README.md`
- `SERVICENOW_DEPENDENCY_CHANGES.md`
- `SERVICENOW_TRANSFER_README.md`

The change role keeps `snow_operation` and the `snow_*` variables. The incident role keeps `snow_incident_operation` and the `snow_incident_*` variables. Results are `snow_result` and `snow_incident_result`.

## 2. Where to extract

Extract into the repository root, the directory that already contains `roles/`, `playbooks/`, and `ansible.cfg`.

After extraction:

- `roles/servicenow_patching_change/tasks/main.yml` exists
- `roles/servicenow_incident/tasks/main.yml` exists
- `playbooks/tests/test_snow_change.yml` exists

## 3. Do not overwrite

Do not replace these client files with anything from another working tree:

- `roles/servicenow_change/`
- `roles/windows_patch/`
- `roles/patch_common/`
- `roles/patch_report/`
- `roles/report_email/`
- `roles/patch_cycle_exception/`
- `roles/windows_patch_source/`
- `playbooks/windows/full_patch.yml`
- `playbooks/windows/precheck.yml`
- `requirements.yml`
- `execution-environments/windows-patch-ee/requirements.yml`

If `playbooks/tests/` already exists, copy only the four ServiceNow test files into it. Do not delete other files in that directory.

This package does not contain `requirements.yml` replacements, credentials, or secrets. The roles read `SN_HOST`, `SN_USERNAME`, and `SN_PASSWORD` from the job environment.

## 4. Merge the collection dependency

Follow `SERVICENOW_DEPENDENCY_CHANGES.md`. Add `servicenow.itsm` version `2.6.3` to both requirements files. Keep the existing `ansible.windows` and `community.general` entries.

## 5. Verify role discovery

From the repository root, with `roles_path` pointing at `roles` (`ansible.cfg` already sets this on a normal checkout):

```bash
test -d roles/servicenow_patching_change/tasks
test -d roles/servicenow_incident/tasks
test -d roles/servicenow_change
```

The third check confirms the existing adapter is still present. If Ansible ignores `ansible.cfg` because the directory is world-writable, export `ANSIBLE_ROLES_PATH=roles` for the commands below.

## 6. Syntax-check

Install the collection locally first if it is not already installed. This does not change the execution environment:

```bash
ansible-galaxy collection install servicenow.itsm:==2.6.3
ansible-playbook --syntax-check \
  playbooks/tests/test_snow_change.yml \
  playbooks/tests/snow_role_test.yml \
  playbooks/tests/snow_incident_test.yml
```

## 7. AAP test job template

Create a new job template. Do not point it at `playbooks/windows/full_patch.yml`.

| Field | Value |
| --- | --- |
| Playbook | `playbooks/tests/test_snow_change.yml` |
| Inventory | Any inventory that can resolve `localhost` |
| Limit | Empty. A Windows wave limit skips `hosts: localhost` |
| Credential | The custom credential that injects `SN_HOST`, `SN_USERNAME`, and `SN_PASSWORD` |
| Execution environment | An image that already contains `servicenow.itsm` 2.6.3, or `windows-patch-ee` only after that image is rebuilt |
| Verbosity | Normal |

## 8. First test

Run the read playbook against an existing change. Extra variables:

```yaml
snow_test_change_number: CHG0000123
```

Replace the number with a real change in the client instance. The job displays `snow_result`. It does not create, update, or close the change, and it does not patch Windows hosts.

Confirm `snow_result.success` is true and `snow_result.number` matches the change you passed.

## 9. Updates and attachments after the read succeeds

Use `playbooks/tests/snow_role_test.yml` only after the read job succeeds. Every write flag defaults to false.

Work note on the same existing change:

```yaml
snow_test_enable_work_note: true
snow_test_work_note_number: CHG0000123
snow_test_aap_job_id: "830"
```

Sample report attachment on that same change. This writes three small files in the current job and uploads them. It does not create or close a change:

```yaml
snow_test_enable_sample_files: true
snow_test_enable_attach_reports: true
snow_test_attach_number: CHG0000123
```

Confirm `snow_result.operation` is `attach_reports` and `snow_result.attachments` lists `report.json`, `report.csv`, and `report.md`.

Leave `snow_test_enable_create`, `snow_test_enable_close`, and `snow_test_enable_add_cis` false until those operations are explicitly requested. Incident create, update, and close in `playbooks/tests/snow_incident_test.yml` also stay off unless their flags are set to true.
